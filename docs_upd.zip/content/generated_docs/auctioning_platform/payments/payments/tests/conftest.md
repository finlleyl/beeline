Программа добавляет в pytest два новых параметра:  

* `--stripe-publishable-key` для хранения публичного ключа Stripe;
* `--stripe-secret-key` для секретного ключа Stripe.