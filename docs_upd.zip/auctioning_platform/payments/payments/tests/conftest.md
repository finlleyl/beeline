Программа добавляет в pytest два новых аргумента командной строки:  
* `--stripe-publishable-key` для хранения публичного ключа Stripe;
* `--stripe-secret-key` для секретного ключа Stripe.